package com.greenfoxacademy.springstart;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringstartApplicationTests {

	@Test
	public void contextLoads() {
	}

}
